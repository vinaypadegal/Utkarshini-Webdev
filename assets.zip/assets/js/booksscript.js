$(document).ready(function() {

  $('.color-choose input').on('click', function() {
      var headphonesColor = $(this).attr('data-image');

      $('.active').removeClass('active');
      $('.left-column img[data-image = ' + headphonesColor + ']').addClass('active');
      $(this).addClass('active');
  });

});

/*Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo sed augue eu commodo. Fusce ut arcu nec nulla sagittis bibendum. In pellentesque libero eu lacus convallis, et imperdiet leo consequat. Fusce at ipsum augue. Pellentesque et urna eu nunc tempor dignissim. Aliquam imperdiet ante id cursus condimentum. Donec arcu neque, imperdiet a velit vitae, efficitur tempor arcu. Maecenas imperdiet eros nisi, nec sagittis lectus lacinia in.*/

/*Mauris suscipit, elit quis aliquet gravida, nulla lorem fermentum sem, a hendrerit sem orci nec quam. Mauris eu enim a eros elementum faucibus id id lorem. Integer vel mollis mi. Maecenas at neque sit amet risus dignissim lobortis sed vel diam. Nam non urna pretium, aliquet ante ut, dictum tellus. Donec sit amet aliquam dolor, at convallis est. Nunc arcu mauris, commodo et lorem sed, volutpat hendrerit mi. Sed sit amet lorem malesuada, iaculis felis vel, finibus urna. Integer eleifend sapien eu accumsan iaculis. Fusce eu quam nec dolor efficitur porttitor. Nullam blandit velit vel erat blandit, egestas fringilla libero varius. Aliquam tortor tellus, efficitur consequat blandit volutpat, consectetur at libero. In venenatis efficitur dignissim. Quisque et auctor libero. Aenean volutpat rhoncus porttitor. Ut feugiat orci eget lobortis vehicula.*/

/*Suspendisse laoreet nec nibh ut euismod. Nulla dignissim vulputate dolor, vel euismod leo dignissim at. Donec nulla dolor, iaculis vel mattis sed, elementum nec turpis. Fusce pellentesque mi nec tortor tincidunt accumsan. Nulla facilisi. Aliquam ac placerat ipsum, mollis posuere velit. Fusce efficitur arcu nibh, ut ullamcorper nulla elementum malesuada. Etiam tortor metus, rhoncus quis turpis hendrerit, tristique dignissim arcu. Vivamus et turpis vulputate est consequat efficitur congue sed augue. Ut metus sapien, faucibus nec euismod sit amet, finibus vel arcu. Vestibulum laoreet erat vel velit volutpat, ut vulputate urna bibendum. Vestibulum eleifend felis ut urna egestas malesuada. Mauris vel sem elit. Morbi mollis ligula lorem, nec luctus arcu vulputate non.*/

/*Ut dolor orci, pellentesque a neque vel, maximus dictum est. Ut eu sagittis felis. Nullam mollis purus eu porta interdum. Aliquam in commodo neque, at faucibus metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Phasellus congue varius dignissim. Phasellus est velit, auctor pretium tortor faucibus, tristique sodales sem. Nunc ornare nisl in lorem imperdiet, nec suscipit quam tristique. Donec vestibulum dolor eget scelerisque tempor. Ut et turpis id justo interdum iaculis nec id quam. Morbi iaculis lacinia leo eu sollicitudin. Nam tempus sem nec faucibus ullamcorper. Nam semper pharetra augue vitae facilisis. Phasellus ut eros sit amet elit semper interdum. Mauris aliquam euismod justo id fringilla.*/

/*Sed ut eleifend nunc, non posuere augue. Praesent dignissim congue pellentesque. Pellentesque quis placerat tellus. Quisque porta quis purus eu tincidunt. Ut tincidunt, est id placerat tincidunt, nisl ante lobortis velit, sit amet lacinia risus sapien at arcu. Cras et diam a dui consequat scelerisque. Aliquam efficitur ornare justo, non tincidunt lectus accumsan in.*/